#include <iostream>
#include <stdlib.h>

using namespace std;

struct node
{
    int data;
    struct node *prev;
};

int number_of_nodes = 0;

struct node *head = NULL, *ptr, *temp;

int pop()
{
        int elem;
        ptr = head;
        elem = ptr -> data;
        head = ptr -> prev;
        ptr -> prev = NULL;
        free(ptr);
        number_of_nodes--;
        return elem;
}

void push(int elem)
{
    temp = (struct node*)malloc(sizeof(struct node));
    temp -> data = elem;
    if(head == NULL){
        temp -> prev = NULL;
        head = temp;
    }
    else{
        temp -> prev = head;
        head = temp;
    }
    number_of_nodes++;
}

int isEmpty()
{
    if(number_of_nodes == 0) return 1;
    else return 0;
}

int peek()
{
    return head -> data;
}

void display()
{
    ptr = head;
    while(ptr != NULL)
    {
        cout << ptr -> data << endl;
        ptr = ptr -> prev;
    }
}

int main()
{
    push(1);
    push(2);
    push(3);
    push(4);
    push(5);
    push(6);



    display();


    cout << "Head data is : " << head -> data << endl;


    int value = pop();

    cout << "Popped element is : " << value << endl;


    display();

    cout << "Head data is : " << head -> data << endl;

    isEmpty() ? cout << "The stack is empty!" : cout << "The stack is not empty!";
    cout << endl;
    display();
    int a = pop();
    int b = pop();
    int c = pop();
    int d = pop();
    int e = pop();

    isEmpty() ? cout << "The stack is empty!" : cout << "The stack is not empty!";
    cout << endl;
    display();



    return 0;
}
