#include <iostream>
#include <stdlib.h>

using namespace std;

struct node
{
    int data;
    struct node *prev;
};

int number_of_nodes = 0;

struct node *head = NULL, *ptr, *temp, *maxNode;

void findMaxAndPlaceItLast()
{
    maxNode = head;
    struct node *ptr2;
    ptr = head;
    while(ptr != NULL)
    {
        if(ptr -> data > maxNode -> data){
            maxNode = ptr;
        }
        ptr = ptr -> prev;
    }
    int tempValue;
    tempValue = maxNode -> data;
    maxNode -> data = head -> data;
    head -> data = tempValue;


}

int pop()
{
        int elem;
        ptr = head;
        elem = ptr -> data;
        head = ptr -> prev;
        ptr -> prev = NULL;
        free(ptr);
        number_of_nodes--;
        findMaxAndPlaceItLast();
        return elem;
}

void push(int elem)
{
    temp = (struct node*)malloc(sizeof(struct node));
    temp -> data = elem;
    if(head == NULL){
        temp -> prev = NULL;
        head = temp;
    }
    else{
        temp -> prev = head;
        head = temp;
    }
    number_of_nodes++;
}

int isEmpty()
{
    if(number_of_nodes == 0) return 1;
    else return 0;
}

int peek()
{
    return head -> data;
}

void display()
{
    ptr = head;
    while(ptr != NULL)
    {
        cout << ptr -> data << endl;
        ptr = ptr -> prev;
    }
}

int main()
{
    push(45);
    push(23);
    push(56);
    push(35);
    push(12);
    push(32);



    display();


    cout << "Head data is : " << head -> data << endl;


    int value1 = pop();

    cout << "Popped element is : " << value1 << endl;
    display();


    int value2 = pop();

    cout << "Popped element is : " << value2 << endl;
    display();

    cout << "Head data is : " << head -> data << endl;

    isEmpty() ? cout << "The stack is empty!" : cout << "The stack is not empty!";
    cout << endl;




    isEmpty() ? cout << "The stack is empty!" : cout << "The stack is not empty!";
    cout << endl;

    return 0;
}
