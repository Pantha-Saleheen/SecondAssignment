#include <iostream>

using namespace std;

#define SIZE 5

int arr[SIZE];
int totalElement = 0, Front = 0, rear = -1;

int isEmpty()
{
if(totalElement == 0) return 1;
return 0;
}

void display()
{
for(int i = 0; i < totalElement; i++){
cout << arr[i] << endl;
}
}

int peek()
{
return arr[Front];
}

void enqueue(int elem)
{
if(totalElement == SIZE){
cout << "Sorry! The queue is full." << endl;
return;
}
rear++;
arr[rear] = elem;
totalElement++;
}

int dequeue()
{
int frontElement = Front;
if(isEmpty()){
cout << "Sorry! You can not dequeue." << endl;
}
Front++;
totalElement--;
return arr[frontElement];
}

int main()
{
enqueue(1);
enqueue(2);
enqueue(3);
enqueue(4);
enqueue(5);
display();
cout << "Value by peek operation : " << peek() << endl;
if(isEmpty()){
cout << "The queue is empty!" << endl;
}
else{
cout << "The queue is not empty!" << endl;
}
cout << "Value by dequeue operation : " << dequeue() << endl;
return 0;
}
