#include <iostream>

using namespace std;

#define SIZE 5

int arr[SIZE];
int totalElement = 0, Front = 0, rear = -1;

int isEmpty()
{
    if(totalElement == 0) return 1;
    return 0;
}

void display()
{
    for(int i = 0; i < SIZE; i++){
        cout << arr[i] << endl;
    }
}

int peek()
{
    return arr[Front];
}

void enqueue(int elem)
{
    if(totalElement == SIZE){
    cout << "Sorry!"<< elem << " can not be inserted. Queue is full." << endl;
    return;
}
    rear = (rear + 1) % SIZE;
    arr[rear] = elem;
    totalElement++;
}

int dequeue()
{
    int frontElement = arr[Front];
    if(isEmpty()){
    cout << "Sorry! You can not dequeue." << endl;
}
    arr[Front] = -1;
    Front = (Front + 1) % SIZE;
    totalElement--;
    return frontElement;
}

int main()
    {
    enqueue(1);
    enqueue(2);
    enqueue(3);
    enqueue(4);
    enqueue(5);
    enqueue(6);
    display();
    cout << "Peeked value is : " << peek() << endl;
    if(isEmpty()){
    cout << "The queue is empty!" << endl;
    }
    else{
    cout << "The queue is not empty!" << endl;
    }
    cout << "After dequeue operation, return element is : " << dequeue() << endl;
    enqueue(6);
    display();
    cout << "After dequeue operation, return element is : " << dequeue() << endl;
    display();
    cout << "After adding 70 to the queue : " << endl;
    enqueue(70);
    display();
    return 0;
}
